# HaLo: Estimation and Reduction of Hallucinations in Open-Source Weak Large Language Models
